# REPOsitory.XvBMC
 
**NOTE:** XvBMC Nederland (xbmc nl) wij zijn géén helpdesk van/voor boxverkopers
 
  
   
### XvBMC_Nederland: 
* https://bit.ly/XvBMC-NL 
* https://www.fb.com/groups/XvBMCnederland/ 
 
### OFFLINE / AFGESLOTEN / SHUTDOWN / DOWN: 
 
Op last van Stichting BREIN wordt 'XvBMC Repository' niet langer aangeboden, omdat middels deze repository op grote schaal films, tv-series en muziek zonder toestemming ter beschikking werden gesteld. Het aldus ter beschikking stellen aan het publiek van auteursrechterlijk beschermde werken maakt inbreuk op de auteursrechten en naburige rechten van de rechthebbenden op die werken. Ook het streamen uit ongeautoriseerde bron is verboden in Nederland. 'XvBMC Repository' is met Stichting BREIN tot een schikking gekomen. Voor aanbieders van legale content verwijst 'XvBMC Repository' u naar thecontenmap.nl en film.nl
 
**NUANCE:**
*Volgens ons, XvBMC Nederland, is deze nuance weldegelijk op zijn plaats; Wij (XvBMC-NL) hebben **ZELF** nooit films, tv-series en muziek zonder toestemming ter beschikking gesteld!*
  
----------
  
*With kind regards,*
 
*Team X(v)BMC Nederland*
  
----------
  
(c) [XvBMC Nederland](https://bit.ly/XvBMC-NL) (r)